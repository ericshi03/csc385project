#pragma once

void light_init();
float read_light();