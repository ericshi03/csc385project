#pragma once

void humid_init();
float read_humidity();