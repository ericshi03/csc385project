#pragma once

void temp_init();
float read_temperature();