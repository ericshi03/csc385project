#include "mbed.h"
#include "EthernetInterface.h"
#include "MQTTClient.h"

static EthernetInterface eth;
static NetworkInterface* network = &eth;

#define MQTT_BROKER_ADDRESS "test.mosquitto.org"
#define MQTT_BROKER_PORT 1883
      
static TCPSocket socket;
static MQTTClient client(&socket);

bool mqtt_connect(const char* client_id) {
    nsapi_error_t net_status = network->connect();
    if (net_status != 0) {
        printf("Network connection failed: %d\n", net_status);
        return false;
    }

    socket.open(network);
    printf("Connecting to Mosquitto broker %s:%d\n", MQTT_BROKER_ADDRESS, MQTT_BROKER_PORT);
    int rc = socket.connect(MQTT_BROKER_ADDRESS, MQTT_BROKER_PORT);
    if (rc != 0) {
        printf("Connect failed w/ Error Code: %d\n", rc);
        return false;
    }

    MQTTPacket_connectData data = MQTTPacket_connectData_initializer;
    data.MQTTVersion = 3;
    data.clientID.cstring = client_id;
    
    rc = client.connect(data);
    if (rc != 0) {
        printf("Connect failed w/ Error Code: %d\n", rc);
        return false;
    }
    
    printf("Connected to Mosquitto broker\n");
    return true;
}

bool mqtt_publish(const char* message, const char* MQTT_TOPIC) {
    MQTT::Message msg;
    msg.qos = MQTT::QOS1;
    msg.retained = false;
    msg.dup = false;
    msg.payload = (void*)message;
    msg.payloadlen = strlen(message);
    
    int rc = client.publish(MQTT_TOPIC, msg);
    if (rc != 0) {
        printf("Message publish failed: %d\n", rc);
        return false;
    }
    printf("Message published: %s\n", message);
    return true;
}

void mqtt_disconnect() {
    if (client.isConnected()) {
        client.disconnect();
        socket.close();
        network->disconnect();
        printf("Disconnected from Mosquitto broker\n");
    }
}